import { Navigate, NavLink, Outlet, useLocation } from "react-router-dom";
import { cn, Loading } from "@mobileflow/ui";
import { ArrowLeft } from "lucide-react";
import { useAuth } from "../auth/AuthProvider";
import { ThemeToggle } from "../theme/ThemeToggle";
import { UserMenu } from "../shell/UserMenu";

export function AdminLayout() {
  const { status, me } = useAuth();
  const location = useLocation();
  if (status === "loading") {
    return (
      <div className="app-shell">
        <div className="empty-state" style={{ margin: "auto" }}>
          <Loading />
        </div>
      </div>
    );
  }
  if (!me?.user.isSuperadmin) return <Navigate to="/" replace />;

  return (
    <div className="app-shell">
      <aside className="app-rail-inner app-scroll">
        <div className="app-rail-section-title">Admin</div>
        <nav className="app-rail-nav">
          <Item to="/admin" end label="Overview" />
          <Item to="/admin/company" label="Company" />
          <Item to="/admin/orgs" label="Organizations" />
          <Item to="/admin/users" label="Users" />
          <Item to="/admin/builds" label="Builds" />
          <Item to="/admin/plans" label="Plans" />
          <Item to="/admin/hosts" label="Build hosts" />
          <Item to="/admin/stacks" label="Build stacks" />
          <Item to="/admin/oauth-apps" label="OAuth apps" />
          <Item to="/admin/payment-processors" label="Payment processors" />
          <Item to="/admin/payments" label="Payments" />
          <Item to="/admin/database" label="Database" />
          <Item to="/admin/deploy" label="Deploy" />
          <Item to="/admin/logs" label="Logs" />
        </nav>
        {/* The label lives inside the link so clicking the words navigates too
            — it used to be a sibling, leaving only the 24px badge clickable. */}
        <NavLink to="/" className="admin-back-row" style={{ marginTop: 16 }}>
          <span className="admin-back-btn" aria-hidden>
            <ArrowLeft size={14} />
          </span>
          <span className="admin-back-label">Back to app</span>
        </NavLink>
      </aside>
      <main className="app-main">
        <header className="app-header">
          <ThemeToggle />
          <UserMenu />
        </header>
        <div className="app-content app-scroll page-fade" key={location.pathname}>
          <Outlet />
        </div>
      </main>
    </div>
  );
}

function Item({ to, label, end }: { to: string; label: string; end?: boolean }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) => cn("app-rail-nav-item", isActive && "is-active")}
    >
      {label}
    </NavLink>
  );
}
